import React from 'react'
 
export default function Home(props){
    return(
        <div align="center">
             <h2>Welcome To Notes App</h2>
        </div>
    )
}