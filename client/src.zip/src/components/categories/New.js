import React from 'react'
import axios from 'axios'
import CategoryForm from './Form'

export default class CategoryNew extends React.Component{
   handleSubmit=(formData)=>{
       console.log(formData,89)
       axios.post('http://localhost:3025/categories',formData,{
           headers:{'x-auth':localStorage.getItem('authToken')}
       })
       .then((response)=>{
            if(response.data.hasOwnProperty('errors'))
            {
                alert(response.data.errors.message)
            }
            else{
                const category=response.data
                console.log(response.data,3)
                this.props.history.push(`/categories/${category._id}`) 
            }
       })
       .catch((err)=>{
            console.log(err)
       })
   }
render(){
    return(
        <div align="center">
            <h2>Add Category</h2>
            <CategoryForm  handleSubmit={this.handleSubmit}></CategoryForm>
        </div>
    )
}
}