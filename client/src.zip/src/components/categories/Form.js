import React from 'react'
import {Link} from 'react-router-dom'
import axios from 'axios'

export default class CategoryForm extends React.Component{
    constructor(props){
        super(props)
        this.state={
            name:props.name?props.name:'',
            category:{}
        }
    }

handleSubmit=(e)=>{
    e.preventDefault()
    const formData={
        name:this.state.name
    }
    console.log(formData,7777)
    this.props.handleSubmit(formData)
}
handleChange=(e)=>{
    this.setState({[e.target.name]:e.target.value})
}
render(){
    return(
        <div align="center">
           <form onSubmit={this.handleSubmit}>
                <label>Name<br/>
                    <input type="text" value={this.state.name} onChange={this.handleChange} name="name"/>
                </label><br/>
                <input type="submit"/>
           </form>

        </div>
    )
}
}