import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'
import CategoryForm from './Form'

export default class CategoryEdit extends React.Component{
    constructor(props){
        super(props)
        this.state={
            category:{}
        }
    }
componentDidMount(){
    const id=this.props.match.params.id
    console.log(id)
    axios.get(`http://localhost:3025/categories/${id}`,{
        headers:{
            'x-auth':localStorage.getItem('authToken')
        }
    })
    .then(response=>{
       const category=response.data
       this.setState({category})
    })
}
handleSubmit=(formData)=>{
    axios.put(`http://localhost:3025/categories/${this.state.category._id}`,formData ,{
        headers: {'x-auth':localStorage.getItem('authToken')}
    })
    .then((response)=>{
        if(response.data.hasOwnProperty('errors')){
            alert(response.data.errors.message)
        }
        else
        {
          const category=response.data
          this.props.history.push(`/categories/${category._id}`)
        }
       })
       .catch((err)=>{
           console.log(err)
       })
}
    render(){
        return(
            <div align="center">
                <h2>Edit Note-{this.state.category.name}</h2>
                {
                    Object.keys(this.state.category).length!==0 && <CategoryForm {...this.state.category} handleSubmit={this.handleSubmit} />
                
        }
            </div>
        )
    }
}