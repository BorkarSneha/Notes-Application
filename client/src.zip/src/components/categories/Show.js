import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'

export default class CategoryShow extends React.Component{
    constructor(props){
        super()
            this.state={
                category:{}
            }
    }
componentDidMount()
{
    console.log(12)
    const id=this.props.match.params.id
    axios.get(`http://localhost:3025/categories/${id}`,{
      headers:{'x-auth':localStorage.getItem('authToken')}
    })
    .then((response)=>{
    
        const category=response.data
        console.log(123,category)
        this.setState({category})

    })
    .catch((err)=>{
        console.log(err,11)
    })
}
render(){
    return(
        <div align="center">
             <h3>NAME-{this.state.category.name}</h3>
             <Link to={`/categories/edit/${this.state.category._id}`}>Edit</Link><br/>
          <Link to="/categories">Back</Link>     
        </div>
    )
}
}
