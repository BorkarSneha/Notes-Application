import React from 'react'
import {Link} from 'react-router-dom'
import axios from 'axios'

export default class CategoryList extends React.Component{
    constructor(props){
        super(props)
        this.state={
            categories:[]
        }
    }
componentDidMount(){
    axios.get('http://localhost:3025/categories',{
        headers:{'x-auth':localStorage.getItem('authToken')}
    })
    .then((response)=>{
        const categories=response.data
        this.setState({categories})

    })
    .catch((err)=>{
        console.log(err)
    })
}
handleRemove=(id)=>{
    console.log(1)
    axios.delete(`http://localhost:3025/categories/${id}`,{
        headers:{'x-auth':localStorage.getItem('authToken')}
    }) 
    .then((response)=>{
        console.log(2)
        this.setState((prevState)=>{
            return{
                categories:prevState.categories.filter(category=> category._id !== id)
            }
        })
        console.log(3)
    })
    .catch((err)=>{
        console.log(4)
        console.log(err)
    })
}
render(){
    return(
        <div align="center">
            <h2>Listing Categories-{this.state.categories.length}</h2>
            <table border="1">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Action</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.state.categories.map((category)=>{
                            return(
                                <tr key={category._id}>
                                    <td>{category.name}</td>
                                    <td><Link to={`categories/${category._id}`}>Show</Link></td>
                                    <td><button onClick={()=>{this.handleRemove(category._id)}}>Remove</button></td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <Link to="/categories/new">Add Categories</Link>
        </div>
    )
}
}
