import React from 'react'
import NotesForm from './Form'
import axios from 'axios'
export default class NotesEdit extends React.Component{
    constructor(props){
        super(props)
        this.state={
            note:{}
        }
    }

componentDidMount(){
    const id=this.props.match.params.id
    axios.get(`http://localhost:3025/notes/${id}`,{
        headers:{
            'x-auth':localStorage.getItem('authToken')
        }
    })
    .then(response=>{
       const note=response.data
       this.setState({note})
    })
}

handleSubmit=(formData)=>{
    axios.put(`http://localhost:3025/notes/${this.state.note._id}`,formData ,{
        headers: {'x-auth':localStorage.getItem('authToken')}
    })
    .then((response)=>{
        if(response.data.hasOwnProperty('errors')){
            alert(response.data.errors.message)
        }
        else
        {
          const note=response.data
          this.props.history.push(`/notess/${note._id}`)
        }
       })
       .catch((err)=>{
           console.log(err)
       })
}
    render(){
        return(
            <div>
                <h2>Edit Note-{this.state.note.title}</h2>
                {
                    Object.keys(this.state.note).length!==0 && <NotesForm {...this.state.note} handleSubmit={this.handleSubmit} />
                
        }
            </div>
        )
    }
}