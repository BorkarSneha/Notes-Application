import React from 'react'
import axios from 'axios'
import NotesForm from './Form'

export default class NotesNew extends React.Component{
    handleSubmit=(formData)=>{
        axios.post('http://localhost:3025/notes',formData ,{
            headers: {'x-auth':localStorage.getItem('authToken')}
        })
        .then((response)=>{
            if(response.data.hasOwnProperty('errors')){
                alert(response.data.errors.message)
            }
            else
            {
              const note=response.data
              this.props.history.push(`/notes/${note._id}`)
            }
           })
           .catch((err)=>{
               console.log(err)
           })
    }
render(){
    return (
        <div align="center">
            <h2>ADD NOTES</h2>
            <NotesForm handleSubmit={this.handleSubmit}></NotesForm>
        </div>
    )
}
}