import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'
export default class NotesList extends React.Component{
    constructor(){
        super()
        this.state={
            notes:[]
        }
    }
    componentDidMount(){
        axios.get('http://localhost:3025/notes',{
            headers:{'x-auth':localStorage.getItem('authToken')}
        })
        .then((response)=>{
            console.log(response.data)
            const notes=response.data
            this.setState({notes})
        })
        .catch((err)=>{
            console.log(err)
        })
    }
    
    handleRemove = (id)=>{
        console.log(1)
        axios.delete(`http://localhost:3025/notes/${id}`,{
            headers: {'x-auth':localStorage.getItem('authToken')}
        })
        .then((response)=>{
          console.log(response.data,this.state.notes)
            this.setState((prevState)=>{
                return {

                    notes:prevState.notes.filter(note => note._id !== id)
                }
               
            })

        })
        .catch((err)=>{
            console.log(4)
            console.log(err)
        })
    }
    render(){
        return(
                <div align="center">
                <h2>Listing Notes-{this.state.notes.length}</h2>
                <table border="1">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Body</th>
                            <th>Category</th>
                            <th>Action</th>
                            <th>Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.notes.map((note)=>{
                                return(
                                    <tr key={note._id}>
                                        <td>{note.title}</td>
                                        <td>{note.body}</td>
                                        <td>{note.category.name}</td>
                                        <td><Link to={`notes/${note._id}`}>Show</Link></td>
                                        <td><button onClick={()=>{this.handleRemove(note._id)}}>Remove</button></td>
                                        

                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
                <Link to="/notes/new">Add Notes</Link>
                </div>
       
        )
    }
}