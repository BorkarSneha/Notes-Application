import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'

export default class NotesShow extends React.Component{
    constructor(props){
        super()
            this.state={
                note:{},
                category:{}
            }
    }
componentDidMount(){
    const id=this.props.match.params.id
    console.log(id,12345)
    axios.get(`http://localhost:3025/notes/${id}`,{
      headers:{'x-auth':localStorage.getItem('authToken')}
    })
    .then((response)=>{
        const note=response.data
        
        const category=note.category
        this.setState({note,category})

    })
    .catch((err)=>{
        console.log(err)
    })
}
render(){
   console.log(this.state.category,124)
    return(
        <div align="center">
             <h3>TITLE-{this.state.note.title}</h3>
             <h3>BODY-{this.state.note.body}</h3>
             <h3>CATEGORY-{this.state.category.name}</h3>
             <Link to={`/notes/edit/${this.state.note._id}`}>Edit</Link><br/>
          <Link to="/notes">Back</Link>     
        </div>
    )
}
}
