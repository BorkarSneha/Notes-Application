import React from 'react'
import axios from 'axios'

class Login extends React.Component{
      constructor(props){
          super(props)
          this.state={
              email:'',
              password:''
          }
      }
handleSubmit=(e)=>{
    e.preventDefault()
    const formData={
        email:this.state.email,
        password:this.state.password
    }
axios.post('http://localhost:3025/users/login',formData)
       .then((response)=>{
           if(response.data.error){
               alert(response.data.error)
           }
           else{
              // console.log(response.data.token,12)
               const token=response.data.token
               localStorage.setItem('authToken',token)
               alert("successfully loggedin")
               this.props.history.push('/')
           }
       })
       .catch((err)=>{
           console.log(err)
       })
}
handleChange=(e)=>{
    this.setState({[e.target.name]:e.target.value})
}
render(){
    return(
        <div align="center">
            <h2>Login User</h2>
            <form onSubmit={this.handleSubmit}>
              <label>Email <br/>
                  <input type="text" value={this.state.email} onChange={this.handleChange} name="email"/>
              </label>
              <br/>
              <label>Password <br/>
                  <input type="password" value={this.state.password} onChange={this.handleChange} name="password"/>
              </label>
              <br/>
              <input type="Submit"/>
            </form>
        </div>
    )
}
}

export default Login