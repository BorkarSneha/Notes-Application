import React from 'react';
import {BrowserRouter,Route,Link,Switch} from 'react-router-dom'
import Home from './components/common/Home'
import Register from './components/users/Register'
import Login from './components/users/Login'
import Logout from './components/users/Logout'

import NotesList from './components/notes/List'
import NotesShow from './components/notes/Show'
import NotesNew from './components/notes/New'
import NotesEdit from './components/notes/Edit'

import CategoryList from './components/categories/List'
import CategoryShow from './components/categories/Show'
import CategoryNew from './components/categories/New'
import CategoryEdit from './components/categories/Edit'

function App() {
  return (
   <BrowserRouter>
       <div>
         <div align="right">
         <Link to="/">Home </Link>
         {
           localStorage.getItem('authToken') ? (
             <div>
               <Link to="/notes">Notes </Link>|<Link to="/categories"> Categories </Link> |
             </div>
           ):(
             <div>
               <Link to="/users/register"> Register </Link>|<Link to="/users/login"> Login </Link>|<Link to="/users/logout"> Logout </Link> |
             </div>
           )
         }
         </div>
         <div align="center"><h1>NOTES APPLICATION</h1></div>

         <Switch>
         <Route path="/" component={Home} exact={true} />
         <Route path="/users/register" component={Register} exact={true} />
         <Route path="/users/login" component={Login} exact={true} />
         

         <Route path="/notes" component={NotesList} exact={true} />
         <Route path="/notes/new" component={NotesNew} exact={true}/>
         <Route path="/notes/edit/:id" component={NotesEdit} exact={true}/>
         <Route path="/notes/:id" component={NotesShow} exact={true}/>

         <Route path="/categories" component={CategoryList} exact={true}/>
         <Route path="/categories/new" component={CategoryNew} exact={true} />
         <Route path="/categories/edit/:id" component={CategoryEdit} exact={true}/>
         <Route path="/categories/:id" component={CategoryShow} exact={true} />
         </Switch>
       

       </div>
   </BrowserRouter>
  )
}

export default App;
